----------------------------------------------------------------------

                  More Bosses+ was made by KroNodes.

  Please do not copy or redistribute my work without my permission.
                Media and fan creations are permitted.
           Please give 100% credit to the original creator.

----------------------------------------------------------------------

Discord: Cro#2864
Reddit: u/KroNodes
Planet Minecraft: KroNodes